 {{-- <h4>{{$databody["start_url"]}}</h4> 
<iframe src="{{$databody["start_url"]}}" style="width: 99%;height: 550px"></iframe> --}}
{{-- <iframe scrolling="no" style="width:100%; height: 500px"
 sandbox="allow-forms allow-scripts allow-same-origin allow-popups allow-modals allow-top-navigation allow-top-navigation-by-user-activation allow-orientation-lock" 
 allowfullscreen allow="encrypted-media; autoplay; microphone; camera" login_required="no" 
src="{{$databody["start_url"]}}" 
frameborder="0"></iframe> --}}

<a href="{{$databody["start_url"]}}" target="_self">Jion</a>