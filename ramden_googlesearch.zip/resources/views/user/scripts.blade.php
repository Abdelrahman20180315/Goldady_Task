<script src="{{asset('user/js/jquery.min.js')}}"></script>
      <script src="{{asset('user/js/popper.min.js')}}"></script>
      <script src="{{asset('user/js/bootstrap.bundle.min.js')}}"></script>
      <script src="{{asset('user/js/jquery-3.0.0.min.js')}}"></script>
    
      <!-- sidebar -->
      <script src="{{asset('user/js/jquery.mCustomScrollbar.concat.min.js')}}"></script>
      <script src="{{asset('user/js/custom.js')}}"></script>
      <script src="{{asset('https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js')}}"></script>