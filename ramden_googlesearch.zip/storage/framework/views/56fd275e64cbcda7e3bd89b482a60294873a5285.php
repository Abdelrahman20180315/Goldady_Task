 


<a href="<?php echo e($databody["start_url"]); ?>" target="_self">Jion</a><?php /**PATH C:\xampp\htdocs\googlesearch\resources\views/admin/zoommeeting.blade.php ENDPATH**/ ?>