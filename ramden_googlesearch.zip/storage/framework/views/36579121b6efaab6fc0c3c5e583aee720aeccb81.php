<iframe scrolling="no" style="width:100%; height: 500px"
 sandbox="allow-forms allow-scripts allow-same-origin allow-popups allow-modals allow-top-navigation allow-top-navigation-by-user-activation allow-orientation-lock" 
 allowfullscreen allow="encrypted-media; autoplay; microphone; camera" login_required="no" 
src="<?php echo e($joinurl); ?>" 
frameborder="0"></iframe> <?php /**PATH C:\xampp\htdocs\googlesearch\resources\views/user/zoomjoiniframeview.blade.php ENDPATH**/ ?>