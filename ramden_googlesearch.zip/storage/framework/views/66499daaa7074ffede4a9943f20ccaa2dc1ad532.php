<footer>
    <div class="footer">
       <div class="container">
          <div class="row border-top">
             <div class="col-md-6 padding_bottom1   ">
                <h3>Subscribe Now</h3>
                <form class="footer_form">
                   <input class="enter" placeholder="Enter your email" type="type" name="Enter your email">
                   <button class="submit">submit</button>
                </form>
             </div>
             <div class="col-md-6">
                <div class="row">
                   <div class="col-md-5 offset-md-1 padding_bottom1">
                      <h3>Links</h3>
                      <ul class="cont">
                         <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do </li>
                      </ul>
                   </div>
                   <div class="col-md-5 offset-md-1">
                      <h3>Contact us</h3>
                      <ul class="cont">
                         <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do </li>
                      </ul>
                   </div>
                </div>
             </div>
          </div>
       </div>
       <div class="copyright">
          <div class="container">
             <div class="row">
                <div class="col-md-12">
                   <p>© 2022 All Rights Reserved. <a href="#"> </a></p>
                </div>
             </div>
          </div>
       </div>
    </div>
 </footer><?php /**PATH E:\xmp\htdocs\ramden_googlesearch\resources\views/user/footer.blade.php ENDPATH**/ ?>