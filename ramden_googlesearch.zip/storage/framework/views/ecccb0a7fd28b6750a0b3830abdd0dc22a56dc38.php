<script src="<?php echo e(asset('user/js/jquery.min.js')); ?>"></script>
      <script src="<?php echo e(asset('user/js/popper.min.js')); ?>"></script>
      <script src="<?php echo e(asset('user/js/bootstrap.bundle.min.js')); ?>"></script>
      <script src="<?php echo e(asset('user/js/jquery-3.0.0.min.js')); ?>"></script>
    
      <!-- sidebar -->
      <script src="<?php echo e(asset('user/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
      <script src="<?php echo e(asset('user/js/custom.js')); ?>"></script>
      <script src="<?php echo e(asset('https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js')); ?>"></script><?php /**PATH E:\xmp\htdocs\ramden_googlesearch\resources\views/user/scripts.blade.php ENDPATH**/ ?>